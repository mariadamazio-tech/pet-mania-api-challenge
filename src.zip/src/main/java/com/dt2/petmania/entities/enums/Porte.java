package com.dt2.petmania.entities.enums;

public enum Porte {
    PEQUENO,
    MEDIO,
    GRANDE
}
